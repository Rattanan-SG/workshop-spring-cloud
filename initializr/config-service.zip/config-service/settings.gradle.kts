rootProject.name = "config-service"
